#pragma once

int preGame(Player, Player, Goban);
int checkDraw(Goban, int, int);
int playGame(int, int, Player, Player, Goban);